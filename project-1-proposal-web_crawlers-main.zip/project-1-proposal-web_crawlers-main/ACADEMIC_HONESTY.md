ACADEMIC HONESTY:
We have done this assignment completely on our own. We have not copied it, nor have we given my solution to anyone else. We understand that if we are involved in plagiarism or cheating, we will have to sign an official form that we have cheated and that this form will be stored in my official university record. We also understand that we will receive a grade of 0 for the involved assignment and our grade will be reduced by at least one level (e.g., from A to B) for my/our offense, and that we will receive a grade of “F” for the course for any additional offense of any kind.


Asmita Singh
Chinmay Purandare
Sanika Shinde

