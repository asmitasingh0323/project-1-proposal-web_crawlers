# COMMENTS

* missing 4chan api calls
* overall good with no real concerns
* perspective key yet?
* used external site for napkin math. good enough
* storage not mentioned for napkin math 

# NOTES FROM 1:1

* get on appying for api keys etc. 

# Grading

* Data source description: 9/10
* Data collection system: 10/10
* Napkin math: 4/5

## Total

23
