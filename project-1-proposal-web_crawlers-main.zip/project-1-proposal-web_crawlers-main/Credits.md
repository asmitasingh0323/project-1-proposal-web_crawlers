Asmita Singh - Data source, Data measurement & analysis
Chinmay Purandare - Estimated weekly data collection, API endpoints
Sanika Shinde - Abstract, Introduction, System Architecture Diagram

